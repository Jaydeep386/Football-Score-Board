package com.example.android.footballscorecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreOfTeamA = 0;
    int scoreOfTeamB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayOfTeamA(scoreOfTeamA);
        displayOfTeamB(scoreOfTeamB);
    }

    public void displayOfTeamA(int v){
        TextView teamA = (TextView) findViewById(R.id.scoreOfTeamA);
        teamA.setText(String.valueOf(scoreOfTeamA));
    }

    public void displayOfTeamB(int v){
        TextView teamB = (TextView) findViewById(R.id.scoreOfTeamB);
        teamB.setText(String.valueOf(scoreOfTeamB));
    }

    public void touchdownA(View view) {
        scoreOfTeamA += 6;
        displayOfTeamA(scoreOfTeamA);
    }

    public void extra_pointA(View view) {
        scoreOfTeamA += 1;
        displayOfTeamA(scoreOfTeamA);
    }

    public void two_pointA(View view) {
        scoreOfTeamA += 2;
        displayOfTeamA(scoreOfTeamA);
    }

    public void field_goalA(View view) {
        scoreOfTeamA += 3;
        displayOfTeamA(scoreOfTeamA);
    }

    public void safety_pointA(View view) {
        scoreOfTeamA += 2;
        displayOfTeamA(scoreOfTeamA);
    }

    public void touchdownB(View view) {
        scoreOfTeamB += 6;
        displayOfTeamB(scoreOfTeamB);
    }

    public void extra_pointB(View view) {
        scoreOfTeamB += 1;
        displayOfTeamB(scoreOfTeamB);
    }

    public void two_pointB(View view) {
        scoreOfTeamB += 2;
        displayOfTeamB(scoreOfTeamB);
    }

    public void field_goalB(View view) {
        scoreOfTeamB += 3;
        displayOfTeamB(scoreOfTeamB);
    }

    public void safety_pointB(View view) {
        scoreOfTeamB += 2;
        displayOfTeamB(scoreOfTeamB);
    }

    public void reset(View view){
        scoreOfTeamA = 0;
        scoreOfTeamB = 0;
        displayOfTeamA(scoreOfTeamA);
        displayOfTeamB(scoreOfTeamB);
    }

}
